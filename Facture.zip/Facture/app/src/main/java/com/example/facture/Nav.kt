package com.example.facture

import com.example.facture.Login
import com.example.facture.Facture
import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

@Composable
fun Nav(){
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "Login" ){

        composable(route = "Login"){
            Login(navController)
        }

        composable(route = "Facture"){
            Facture(navController)
        }
    }
}