package com.example.facture

import androidx.navigation.NavHostController

fun Facture(navHostController: NavHostController){

}